/*wap to find area of triangle*/
#include<stdio.h>
void main()
{
	int b,c;
	float area;

	printf("\n enter heigth :");
	printf("%d",&b);
	printf("\n enter base :");
	printf("%d",&c);

	area = (b*c)/2;

	printf("area of the triangle : %f\n",area);


}