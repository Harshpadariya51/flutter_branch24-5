/*wap to find area of sqare*/
#include<stdio.h>
void main()
{
	int p_h,area;

	printf("\n enter higth/widh : ");
	scanf("%d",&p_h);

	area = p_h * p_h;

	printf("area of the square : %d\n",area);
}