/*wap tp perimeter of circle*/
#include<stdio.h>
void main()
{
	float redius, perimeter, area, pi=3.14;

	printf("enetr redius of circle : \n");
	scanf("%f",&redius);

	perimeter =2 * pi * redius;
	printf("perimeter of circle");
}