/*1. Enter the marks of 5 students in Chemistry, Mathematics and Physics (each out of 100)
 using a Union named Marks having elements roll no., name, chem_marks, maths_marks and
 phy_marks and then display the percentage of each student.*/

#include <stdio.h>
union union_std
{
    int rollno, chem_marks, maths_marks, phy_marks, total;
    char name[30];
    float per;

} s[5];

void main()
{

    union union_std;

    for (int i = 1; i <= 5; i++)
    {
        printf("Enter your rollno : ");
        scanf("%d", &s[i].rollno);
        printf("rollno : %d\n", s[i].rollno);

        printf("Enter your name : ");
        scanf("%s", &s[i].name);
        printf("name : %s\n", s[i].name);

        printf("Enter your chem_marks : ");
        scanf("%d", &s[i].chem_marks);
        printf("chem_marks : %d\n", s[i].chem_marks);

        printf("Enter your maths_marks : ");
        scanf("%d", &s[i].maths_marks);
        printf("maths_marks : %d\n", s[i].maths_marks);

        printf("Enter your phy_marks : ");
        scanf("%d", &s[i].phy_marks);
        printf("phy_marks : %d\n", s[i].phy_marks);

        s[i].total = s[i].chem_marks + s[i].maths_marks + s[i].phy_marks;
        printf("total : %d\n", s[i].total);

        s[i].per = s[i].total / 3;
        printf("total : %.2f\n", s[i].per);

        printf("\n\n");
    }
}
