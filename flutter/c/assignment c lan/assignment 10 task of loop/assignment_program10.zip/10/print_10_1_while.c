/* 2. WAP to print 10 to 1 using while loop. */

#include <stdio.h>

void main()
{
    int i = 10;
    while (i >= 1)
    {
        printf("\t%d\n", i);
        i--;
    }
}