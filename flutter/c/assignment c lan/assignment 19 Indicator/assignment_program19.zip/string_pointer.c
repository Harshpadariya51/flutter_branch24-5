/*4. Program to find length of string using pointer*/
#include<stdio.h>
#include<string.h>
void main()
{
    char h[20],*r;
    int l;
    printf("/n enter sring : ");
    scanf("%s",h);
    r = h;
    l=strlen(r);
    printf("%d",l);
  

}
