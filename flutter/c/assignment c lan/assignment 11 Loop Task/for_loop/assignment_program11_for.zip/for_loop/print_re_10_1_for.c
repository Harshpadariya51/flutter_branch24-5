/* 2. WAP to print 10 to 1 using for loop. */

#include <stdio.h>

void main()
{
    int i = 10;
    for (i = 10; i >= 1; i--)
    {
        printf("%d\n", i);
    }
}