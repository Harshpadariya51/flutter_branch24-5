/* 5. WAP to print odd no. from 1 to N using for loop. */

#include <stdio.h>

void main()
{
    int i, n;

    printf("\n Enter value of n : ");
    scanf("%d", &n);

    printf("\n Odd numbers from 1 to %d : \n", n);

    for (i=1; i<= n;i++)
    {
        if (i % 2 != 0)
        {
            printf(" %d ", i);
        }
    }
}
