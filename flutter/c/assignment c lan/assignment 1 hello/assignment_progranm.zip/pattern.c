/*wap to desing a pattern using '*' with using \n and \t */
#include<stdio.h>
void main()
{
	printf("first pattern desing : \n\n");

	printf("\n \t\t\t * \t\t *\n");
	printf("\n \t\t * \t\t *\n");
	printf("\n \t * \t\t *\n");
	printf("\n \t\t * \t\t *\n");
	printf("\n \t\t\t * \t\t *\n");

	printf("\n\t 2nd pattern desing : \n\n");

	printf("\n\t\t * \t * \t * \t * \t * \t *\t *\n");
	printf("\n\t * \t * \t * \t * \t * \t * \t * \t *\n");
	printf("\n\t * \t \t * \t \t \t \t \t *\n");
	printf("\n\t * \t \t * \t \t * \t * \t * \t * \n");
	printf("\n\t * \t \t * \t \t * \t \t * \t *\n");
	printf("\n\t * \t * \t * \t * \t * \t * \t *\t *\n");


}