/*wap a program to display basic information*/
#include<stdio.h>
void main()
{
	printf("Harsh Padariya");
	printf("kharavad plot,virpur");
	printf("pin code:-360380");
}