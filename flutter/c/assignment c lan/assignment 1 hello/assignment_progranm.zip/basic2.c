/*write a program to display basic information*/
#include<stdio.h>
void main()
{
	printf("Harsh padariya\n");
	printf("kharavad plot,virpur\n");
	printf("pin code:-360380");
	
}