/*2-Wap to convert string into uppercase*/
#include <stdio.h>
#include<string.h>

void main() 
{
    char str[20]={"Harsh padariya"};

    printf("\n string: %s\n", str);
    printf("\n string convert : %s\n",strupr(str));
    

}
