#include<iostream>
using namespace std;
int main()
{
    cout << "Name : Harsh Padariya"<<endl;
    cout << "Study : BCA"<<endl;
    cout << "Number : 8128895379"<<endl;
    cout << "Email id : padariyaharsh06@gmail.com"<<endl;
    cout << "City : virpur"<<endl;
    cout << "Pin Code : 360380"<<endl;
    return 0;
}
